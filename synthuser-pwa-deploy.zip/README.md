# SynthUser PWA Prototype

SynthUser 是一个 AI 合成用户研究原型，当前版本用于验证 1.0 产品交互与功能结构。

## 本地预览

```bash
npm run dev
```

打开：

```text
http://127.0.0.1:4173/
```

## 当前原型范围

- 定性研究：手动问题、生成访谈笔录、归纳分析
- 定量研究：单选/多选/量表/矩阵打分、统计结果、分析摘要
- 合成人群设定：人口统计、品类行为、价格敏感度、心理标签、配额预览
- 模型设置：Kimi / DeepSeek / 智谱 GLM / 自定义模型的本地 API Key 管理
- PWA：manifest、icon、service worker 静态缓存

当前生成结果为前端模拟数据，用于原型评审；后续可接入真实模型 API。

## PWA 能力

- 支持浏览器安装为独立应用
- 支持离线打开已缓存的原型页面
- 顶部状态条会显示在线/离线/已安装状态
- 支持 PWA 快捷入口：`/?mode=qual` 和 `/?mode=quant`
